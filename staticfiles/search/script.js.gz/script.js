
import helloWorld from './HelloWorld';
import $ from 'jquery';
test(); //'hello world'